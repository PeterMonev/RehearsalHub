﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RehearsalHub.Data.Models;
using static RehearsalHub.Common.ImageConstants;

namespace RehearsalHub.Data.Configuration
{
    public class ApplicationUserConfiguration : IEntityTypeConfiguration<ApplicationUser>
    {
        private static readonly PasswordHasher<ApplicationUser> _hasher = new PasswordHasher<ApplicationUser>();

        private readonly IEnumerable<ApplicationUser> Users = new List<ApplicationUser>()
        {
                 new ApplicationUser
                {
                    Id = "de305d54-75b4-4311-81d9-7ed39190224b",
                    UserName = "admin@rehearsalhub.com",
                    NormalizedUserName = "ADMIN@REHEARSALHUB.COM",
                    Email = "admin@rehearsalhub.com",
                    NormalizedEmail = "ADMIN@REHEARSALHUB.COM",
                    EmailConfirmed = true,
                    SecurityStamp = "939c0540-025c-43f1-9b63-938804008272",
                    PasswordHash = _hasher.HashPassword(null!, "Admin123!"),
                    CreatedOn = DateTime.UtcNow,
                    IsDeleted = false
                },
                new ApplicationUser
                {
                    Id = "seed-user-1",
                    UserName = "rockstar@test.com",
                    NormalizedUserName = "ROCKSTAR@TEST.COM",
                    Email = "rockstar@test.com",
                    NormalizedEmail = "ROCKSTAR@TEST.COM",
                    EmailConfirmed = true,
                    SecurityStamp = "59846067-8896-4874-9160-5582f3c306d1",
                    ProfilePictureUrl = GetRandomUserImage(),
                    PasswordHash = _hasher.HashPassword(null!, "P@ssword123"),
                    CreatedOn = DateTime.UtcNow,
                    IsDeleted = false 
                },
                new ApplicationUser
                {
                    Id = "seed-user-2",
                    UserName = "metalhead@test.com",
                    NormalizedUserName = "METALHEAD@TEST.COM",
                    Email = "metalhead@test.com",
                    NormalizedEmail = "METALHEAD@TEST.COM",
                    EmailConfirmed = true,
                    SecurityStamp = "f4c9448a-6f4e-4f0e-9180-2a86d2358899",
                    ProfilePictureUrl = GetRandomUserImage(),
                    PasswordHash = _hasher.HashPassword(null!, "P@ssword123"),
                    CreatedOn = DateTime.UtcNow,
                    IsDeleted = false
                },
                new ApplicationUser
                {
                    Id = "seed-user-3",
                    UserName = "jazzman@test.com",
                    NormalizedUserName = "JAZZMAN@TEST.COM",
                    Email = "jazzman@test.com",
                    NormalizedEmail = "JAZZMAN@TEST.COM",
                    EmailConfirmed = true,
                    SecurityStamp = "788019a3-5c56-4b8c-8f96-339832679f22",
                    ProfilePictureUrl = GetRandomUserImage(),
                    PasswordHash = _hasher.HashPassword(null!, "P@ssword123"),
                    CreatedOn = DateTime.UtcNow,
                    IsDeleted = false
                },
                new ApplicationUser
                {
                    Id = "seed-user-4",
                    UserName = "bluesman@test.com",
                    NormalizedUserName = "BLUESMAN@TEST.COM",
                    Email = "bluesman@test.com",
                    NormalizedEmail = "BLUESMAN@TEST.COM",
                    EmailConfirmed = true,
                    SecurityStamp = Guid.NewGuid().ToString(),
                    ProfilePictureUrl = GetRandomUserImage(),
                    PasswordHash = _hasher.HashPassword(null!, "P@ssword123"),
                    CreatedOn = DateTime.UtcNow,
                    IsDeleted = false
                },
                new ApplicationUser
                {
                    Id = "seed-user-5",
                    UserName = "funky@test.com",
                    NormalizedUserName = "FUNKY@TEST.COM",
                    Email = "funky@test.com",
                    NormalizedEmail = "FUNKY@TEST.COM",
                    EmailConfirmed = true,
                    SecurityStamp = Guid.NewGuid().ToString(),
                    ProfilePictureUrl = GetRandomUserImage(),
                    PasswordHash = _hasher.HashPassword(null!, "P@ssword123"),
                    CreatedOn = DateTime.UtcNow,
                    IsDeleted = false
                },
                new ApplicationUser
                {
                    Id = "seed-user-6",
                    UserName = "hiphop@test.com",
                    NormalizedUserName = "HIPHOP@TEST.COM",
                    Email = "hiphop@test.com",
                    NormalizedEmail = "HIPHOP@TEST.COM",
                    EmailConfirmed = true,
                    SecurityStamp = Guid.NewGuid().ToString(),
                    ProfilePictureUrl = GetRandomUserImage(),
                    PasswordHash = _hasher.HashPassword(null!, "P@ssword123"),
                    CreatedOn = DateTime.UtcNow,
                    IsDeleted = false
                },
                new ApplicationUser
                {
                    Id = "seed-user-7",
                    UserName = "electro@test.com",
                    NormalizedUserName = "ELECTRO@TEST.COM",
                    Email = "electro@test.com",
                    NormalizedEmail = "ELECTRO@TEST.COM",
                    EmailConfirmed = true,
                    SecurityStamp = Guid.NewGuid().ToString(),
                    ProfilePictureUrl = GetRandomUserImage(),
                    PasswordHash = _hasher.HashPassword(null!, "P@ssword123"),
                    CreatedOn = DateTime.UtcNow,
                    IsDeleted = false
                    },
                    new ApplicationUser
                    {
                        Id = "seed-user-8",
                        UserName = "popstar@test.com",
                        NormalizedUserName = "POPSTAR@TEST.COM",
                        Email = "popstar@test.com",
                        NormalizedEmail = "POPSTAR@TEST.COM",
                        EmailConfirmed = true,
                        SecurityStamp = Guid.NewGuid().ToString(),
                        ProfilePictureUrl = GetRandomUserImage(),
                        PasswordHash = _hasher.HashPassword(null!, "P@ssword123"),
                        CreatedOn = DateTime.UtcNow,
                        IsDeleted = false
                    },
                    new ApplicationUser
                    {
                        Id = "seed-user-9",
                        UserName = "soul@test.com",
                        NormalizedUserName = "SOUL@TEST.COM",
                        Email = "soul@test.com",
                        NormalizedEmail = "SOUL@TEST.COM",
                        EmailConfirmed = true,
                        SecurityStamp = Guid.NewGuid().ToString(),
                        ProfilePictureUrl = GetRandomUserImage(),
                        PasswordHash = _hasher.HashPassword(null!, "P@ssword123"),
                        CreatedOn = DateTime.UtcNow,
                        IsDeleted = false
                    },
                    new ApplicationUser
                    {
                        Id = "seed-user-10",
                        UserName = "garage@test.com",
                        NormalizedUserName = "GARAGE@TEST.COM",
                        Email = "garage@test.com",
                        NormalizedEmail = "GARAGE@TEST.COM",
                        EmailConfirmed = true,
                        SecurityStamp = Guid.NewGuid().ToString(),
                        ProfilePictureUrl = GetRandomUserImage(),
                        PasswordHash = _hasher.HashPassword(null!, "P@ssword123"),
                        CreatedOn = DateTime.UtcNow,
                        IsDeleted = false
                    }
        };
        public void Configure(EntityTypeBuilder<ApplicationUser> entity)
        {
            entity.HasQueryFilter(u => !u.IsDeleted);

            entity.Property(u => u.IsDeleted)
                  .HasDefaultValue(false);

            entity.HasData(Users);
        }
    }
}